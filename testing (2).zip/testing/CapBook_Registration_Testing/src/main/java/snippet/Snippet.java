package snippet;

public class Snippet {
	 When User types the status and clicks on post
	 Then 
}

