package com.cg.registrationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChangePicture {

	WebDriver driver;
	
	
	
	public ChangePicture(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="/html/body/app-root/app-change-profile-pic/div/input")
	WebElement locationBox;
	
	@FindBy(xpath="/html/body/app-root/app-change-profile-pic/div/button")
	WebElement changeButton;



	public WebElement setLocationBox() {
		return locationBox;
	}

	public WebElement setChangeButton() {
		return changeButton;
	}
	
	
	
}
