package com.cg.testingsteps;

import static org.junit.Assert.assertEquals;

import org.openqa.grid.common.RegistrationRequest;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cg.registrationtest.ChangePassword;
import com.cg.registrationtest.ChangePicture;
import com.cg.registrationtest.ForgetPassword;
import com.cg.registrationtest.HomePage;
import com.cg.registrationtest.Login;
import com.cg.registrationtest.Registration;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {
	
	WebDriver driver;
	Registration registration;
	Login login;
	ForgetPassword forgetPassword;
	ChangePassword changePassword;
	Alert alert;
	HomePage home;
	ChangePicture picture;
	
	@Before
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\GMOHANTY\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		registration=new Registration(driver);
		login=new Login(driver);
		forgetPassword=new ForgetPassword(driver);
		changePassword = new ChangePassword(driver);		
	}
	
	@Given("^User is on Signup Form$")
	public void user_is_on_Signup_Form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.get("http://localhost:4200/register");
	}

	@Then("^Title of the signup page should be (.*)$")
	public void title_of_the_signup_page_should_be_CapBook(String arg) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    String title=driver.getTitle();
	    assertEquals(arg, title);
	}

	@When("^firstname column is clicked without entering FirstName$")
	public void firstname_column_is_clicked_without_entering_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getFirstname().click();
	    registration.getLastname().click();
	}

	@Then("^validation message should be appeared as 'First Name should not be empty'$")
	public void validation_message_should_be_appeared_as_First_Name_should_not_be_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("First Name should not be empty", registration.getFirstnameerror().getText());
	}

	@When("^lastname column is clicked without entering LastName$")
	public void lastname_column_is_clicked_without_entering_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getFirstname().sendKeys("Harsha");
	    registration.getLastname().click();
	    registration.getEmail().click();
	    
	}

	@Then("^validation message should be appeared as 'Last Name should not be empty'$")
	public void validation_message_should_be_appeared_as_Last_Name_should_not_be_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Last Name should not be empty", registration.getLastnameerror().getText());
	}

	@When("^Email column is clicked without entering e-mail$")
	public void email_column_is_clicked_without_entering_e_mail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getLastname().sendKeys("Devisetti");
	    registration.getEmail().click();
	    registration.getBody().click();
	}

	@Then("^validation message should be appeared as 'Email should not be empty'$")
	public void validation_message_should_be_appeared_as_Email_should_not_be_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Email should not be empty", registration.getEmailerror().getText());
	    
	}
	
	@When("^Email column is entered in incorrect format e-mail$")
	public void email_column_is_entered_in_incorrect_format_e_mail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		registration.getEmail().sendKeys("harsha@devisetti@gmail.com");
	}

	@Then("^validation message should be appeared as 'Incorrect email'$")
	public void validation_message_should_be_appeared_as_Incorrect_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Incorrect email", registration.getEmailincorrecterror().getText());
	    registration.getEmail().clear();
	    registration.getEmail().sendKeys("harsha@gmail.com");
	    
	}

	@When("^password column is clicked without entering Password$")
	public void password_column_is_clicked_without_entering_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getPassword().click();
	    registration.getMobileno().click();
	}

	@Then("^validation message should be appeared as 'Password should not be empty'$")
	public void validation_message_should_be_appeared_as_Password_should_not_be_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Password should not be empty", registration.getPassworderror().getText());
	    
	}
	
	@When("^password column is entered in incorrect passowrd format$")
	public void password_column_is_entered_in_incorrect_passowrd_format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		registration.getPassword().sendKeys("harsha");
	}

	@Then("^validation message should be appeared as 'password should be min (\\d+) characters'$")
	public void validation_message_should_be_appeared_as_password_should_be_min_characters(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("password should be min 8 characters", registration.getPassowrdincorrecterror().getText());
	    registration.getPassword().clear();
	    registration.getPassword().sendKeys("Harsha@123");
	}
	
	

	@When("^mobileno column is clicked without entering MobileNumber$")
	public void mobileno_column_is_clicked_without_entering_MobileNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		registration.getMobileno().click();
		registration.getGendermale().click();
	   
	}

	@Then("^validation message should be appeared as 'Mobile No\\. should not be empty'$")
	public void validation_message_should_be_appeared_as_Mobile_No_should_not_be_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Mobile No. should not be empty", registration.getMobilenoemptyerror().getText());
	    
	}
	
	@When("^mobileno column is entered incorrect MobileNumber format$")
	public void mobileno_column_is_entered_incorrect_MobileNumber_format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		registration.getMobileno().sendKeys("99999");
	   
	}

	@Then("^validation message should be appeared as 'enter only (\\d+) digits'$")
	public void validation_message_should_be_appeared_as_enter_only_digits(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("enter only 10 digits", registration.getMobilenoerror().getText());
	    registration.getMobileno().clear();
	    registration.getMobileno().sendKeys("9999999999");
	}
	@When("^Gender button is selected$")
	public void gender_button_is_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getGendermale().click();
	}

	@Then("^No error should be displayed$")
	public void no_error_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^Dateofbirth column is clicked without entering dateofbirth$")
	public void dateofbirth_column_is_clicked_without_entering_dateofbirth() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getDateOfBirth().click();
	    registration.getBody().click();
	}

	@Then("^validation message should be appeared as 'Date should not be empty'$")
	public void validation_message_should_be_appeared_as_Date_should_not_be_empty() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals("Date should not be empty", registration.getDateOfBirtherror().getText());
	    registration.getDateOfBirth().sendKeys("01011998");
	}

	@When("^Security question field is selected$")
	public void security_question_field_is_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   registration.getQuestiontext().click();
	}

	@Then("^data should be entered$")
	public void data_should_be_entered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 registration.getQuestiontext().sendKeys("Interstellar");
	}
	
	@When("^Signup button is clicked$")
	public void signup_button_is_clicked() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    registration.getSignup().click();
	}


	
	@Then("^alert message should be displayed as 'added' navigate to login page$")
	public void alert_message_should_be_displayed_as_added_navigate_to_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		assertEquals("added...", alert.getText());
		alert.accept();
		/*alert.dismiss();*/
	
		
		
//		driver.switchTo().alert().accept();
		/*String text=alert.getText();s
		assertEquals("added...",text);*/
	}


	

	@Given("^User is on login page and entering incorrect details$")
	public void user_is_on_login_page_and_entering_incorrect_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user clicks on login by entering incorrect details$")
	public void user_clicks_on_login_by_entering_incorrect_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   login.getEmail().sendKeys("sfzsmakd");
	   login.getPassword().sendKeys("ahbsd");
	   login.getLogin().click();
	}

	@Then("^alert message should be displayed as 'Account details are incorrect\\.\\.'$")
	public void alert_message_should_be_displayed_as_Account_details_are_incorrect() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		assertEquals("Account details are incorrect..", alert.getText());
		alert.accept();
	}

	@Given("^User is on Forgot Password Form$")
	public void user_is_on_Forgot_Password_Form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    login.getForgetPassword().click();
	}

	@When("^Reset Password button is clicked without entering all details$")
	public void reset_Password_button_is_clicked_without_entering_all_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    forgetPassword.setEmail().sendKeys("harsh");
	    forgetPassword.setResetPassword().click();
	}
	
	

	/*@When("^Reset password button is clicked with entering all the details$")
	public void reset_password_button_is_clicked_with_entering_all_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		//assertEquals("Account details are incorrect..", alert.getText());
		alert.accept();
		
	}*/

	@Then("^alert message should be displayed as 'Password Changed\\.\\.\\.'$")
	public void alert_message_should_be_displayed_as_Password_Changed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		assertEquals("Password Changed...", alert.getText());
		alert.accept();
	}
	
	@When("^Reset password button is clicked with entering all the details$")
	public void reset_password_button_is_clicked_with_entering_all_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		forgetPassword.setEmail().sendKeys("a@gmail.com");
		forgetPassword.setAnswer().sendKeys("Interstellar");
		forgetPassword.setNewPassword().sendKeys("Password123");
	    forgetPassword.setResetPassword().click();
		
	}

	

	@Then("^alert message should be displayed saying that 'Password Changed\\.\\.\\.'$")
	public void alert_message_should_be_displayed_saying_that_Password_Changed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		//assertEquals("Password Changed...", alert.getText());
		alert.accept();
	}


	/*@Given("^User is on Change Password Form$")
	public void user_is_on_Change_Password_Form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    login.getChangePassword().click();;
	}*/

	/*@When("^Change Password button is clicked without entering all details$")
	public void change_Password_button_is_clicked_without_entering_all_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    changePassword.setEmail().sendKeys("harsha@gmail.com");
	    changePassword.setChangePassword().click();
	}*/
	
	/*@Then("^alert message should be displayed as 'Account not matched'$")
	public void alert_message_should_be_displayed_as_account_not_matched() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}*/

/*	@When("^Change password button is clicked when new password and confirm password are given different$")
	public void change_password_button_is_clicked_when_new_password_and_confirm_password_are_given_different() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//assertEquals("Password Changed...", alert.getText());
		changePassword.setEmail().sendKeys("harsha@gmail.com");
		changePassword.setOldPassword().sendKeys("password12");
		changePassword.setNewPassword().sendKeys("password123");
		changePassword.setConfirmPassword().sendKeys("password");
	    changePassword.setChangePassword().click();
	}
	
	@Then("^alert message should be displayed as 'password not matched'$")
	public void alert_message_should_be_displayed_as_password_not_matched() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		assertEquals("password not matched", alert.getText());
		alert.accept();
	}

	@When("^Change password button is clicked with entering all the details$")
	public void change_password_button_is_clicked_with_entering_all_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		changePassword.setConfirmPassword().clear();
		changePassword.setConfirmPassword().sendKeys("password123");
	    changePassword.setChangePassword().click();
	}*/

	@Given("^User is logging in$")
	public void user_is_logging_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^enters the valid credentials and clicks on login$")
	public void enters_the_valid_credentials_and_clicks_on_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    login.getEmail().sendKeys("harsha@gmail.com");
	    login.getPassword().sendKeys("Password123");
	    login.getLogin().click();
	}

	@Then("^alert message should be displayed as 'logged in\\.\\.'$")
	public void alert_message_should_be_displayed_as_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		assertEquals("logged in....", alert.getText());
		alert.accept();
	}
	
	@Given("^User wants to change the profile picture$")
	public void user_wants_to_change_the_profile_picture() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   Thread.sleep(1000);
	   home=new HomePage(driver);
		home.setChangePicture().click();
	}

	@When("^User enters the location of the picture$")
	public void user_enters_the_location_of_the_picture() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Thread.sleep(1000);
		picture=new ChangePicture(driver);
		picture.setLocationBox().sendKeys("assets/david.jpg");
	    picture.setChangeButton().click();
	}

	@Then("^alert message should be displayed 'added\\.\\.\\.\\.'$")
	public void alert_message_should_be_displayed_added() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		alert=(Alert) driver.switchTo().alert();
		assertEquals("added....", alert.getText());
		alert.accept();
	}
	
	@When("^User wants to send text as post and clicks the post button$")
	public void user_wants_to_send_text_as_post_and_clicks_the_post_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   Thread.sleep(1000);
	   home.setTextStatus().sendKeys("hello friends");
	   home.setPostTextStatus().click();
	}
	@When("^User wants to delete text post by clicking delete button post will be deleted$")
	public void user_wants_to_delete_text_post_by_clicking_delete_button_post_will_be_deleted() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   Thread.sleep(1000);
	  // home.setDeleteText().click();
	}
	
	@When("^User wants to send photo as post and clicks the post button$")
	public void user_wants_to_send_photo_as_post_and_clicks_the_post_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   Thread.sleep(1000);
	   home.setPictureStatus().sendKeys("assets/rahul.jpg");
	   home.setPostPictureStatus().click();
	}

	@Then("^alert message should be displayed 'posted'$")
	public void alert_message_should_be_displayed_posted() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  Thread.sleep(3000);
	  alert=(Alert) driver.switchTo().alert();
	
		//assertEquals("posted", alert.getText());
		
		alert.accept();
	}

	@Then("^User wants to post a comment on picture by clicking post button$")
	public void user_wants_to_post_a_comment_on_picture_by_clicking_post_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Thread.sleep(1000);
		home.setTextComment().sendKeys("awesome");
	    home.setPostComment().click();
	}

	@Then("^User wants to delete photo post by clicking delete button post will be deleted$")
	public void user_wants_to_delete_photo_post_by_clicking_delete_button_post_will_be_deleted() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   Thread.sleep(1000);
	  // home.setDeletePicturePost().click();
	}
	
	@When("^User clicks on the Friends and Request button$")
	public void user_clicks_on_the_Friends_and_Request_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^User wants to add friends then click on send request button$")
	public void user_wants_to_add_friends_then_click_on_send_request_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^User clicks on add friend button$")
	public void user_clicks_on_add_friend_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^accept the alert message$")
	public void accept_the_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^User clicks on the Logout button$")
	public void user_clicks_on_the_Logout_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^User clicks on the friend request button$")
	public void user_clicks_on_the_friend_request_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^User can accept the request$")
	public void user_can_accept_the_request() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^alert message should be displayed 'friend request accepted'$")
	public void alert_message_should_be_displayed_friend_request_accepted() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^User clicks on the Friends button$")
	public void user_clicks_on_the_Friends_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
	
	
}
