package com.cg.registrationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ChangePassword {
	
	WebDriver driver;

	public ChangePassword(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[1]/div/input")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[2]/div/input")
	WebElement oldPassword;
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[3]/div/input")
	WebElement newPassword;
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[4]/div/input")
	WebElement confirmPassword;
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[5]/button")
	WebElement changePassword;


	public WebElement setEmail() {
		return email;
	}

	public WebElement setOldPassword() {
		return oldPassword;
	}

	public WebElement setNewPassword() {
		return newPassword;
	}

	public WebElement setConfirmPassword() {
		return confirmPassword;
	}

	public WebElement setChangePassword() {
		return changePassword;
	}
	
	
}
