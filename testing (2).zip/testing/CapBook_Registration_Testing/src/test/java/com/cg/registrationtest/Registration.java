package com.cg.registrationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration {
	
	WebDriver driver;

	public Registration(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[9]/button")
	WebElement signup;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[1]/div/input")
	WebElement firstname;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[1]/div/div/div")
	WebElement firstnameerror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[2]/div/input")
	WebElement lastname;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[2]/div/div/div")
	WebElement lastnameerror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[3]/div/input")
	WebElement email;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[3]/div/div/div[1]")
	WebElement emailerror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[3]/div/div/div[2]")
	WebElement emailincorrecterror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[4]/div/input")
	WebElement password;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[4]/div/div/div[1]")
	WebElement passworderror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[4]/div/div/div[2]")
	WebElement passowrdincorrecterror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[5]/div/input")
	WebElement mobileno;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[5]/div/div/div[1]")
	WebElement mobilenoemptyerror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[5]/div/div/div[2]")
	WebElement mobilenoerror;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[6]/div/div[1]/label")
	WebElement gendermale;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[6]/div/div[2]/label")
	WebElement genderfemale;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[7]/div/input")
	WebElement dateOfBirth;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[7]/div/div/div")
	WebElement dateOfBirtherror;
	
	@FindBy(xpath="/html/body")
	WebElement body;
	
	@FindBy(xpath="/html/body/app-root/app-register/html/body/div/div/form/div[8]/input")
	WebElement questiontext;


	
	public WebElement getQuestiontext() {
		return questiontext;
	}

	public WebElement getBody() {
		return body;
	}
	
	public WebElement getEmailincorrecterror() {
		return emailincorrecterror;
	}

	public WebElement getSignup() { 
		return signup;
	}

	public WebElement getFirstnameerror() {
		return firstnameerror;
	}

	public WebElement getLastnameerror() {
		return lastnameerror;
	}

	public WebElement getEmailerror() {
		return emailerror;
	}

	public WebElement getPassworderror() {
		return passworderror;
	}
	
	public WebElement getPassowrdincorrecterror() {
		return passowrdincorrecterror;
	}

	public WebElement getMobilenoemptyerror() {
		return mobilenoemptyerror;
	}

	public WebElement getMobilenoerror() {
		return mobilenoerror;
	}

	public WebElement getDateOfBirtherror() {
		return dateOfBirtherror;
	}

	public WebElement getFirstname() {
		return firstname;
	}

	public WebElement getLastname() {
		return lastname;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getPassword() {
		return password;
	}
	

	public WebElement getMobileno() {
		return mobileno;
	}

	public WebElement getGendermale() {
		return gendermale;
	}

	public WebElement getGenderfemale() {
		return genderfemale;
	}

	public WebElement getDateOfBirth() {
		return dateOfBirth;
	}
	
	

}
