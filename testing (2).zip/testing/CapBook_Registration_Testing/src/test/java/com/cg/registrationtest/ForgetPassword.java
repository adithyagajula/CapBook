package com.cg.registrationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ForgetPassword {
	
	WebDriver driver;

	public ForgetPassword(WebDriver driver) {
		super();
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[1]/div/input")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"forgetAnswer\"]")
	WebElement answer;
	
	@FindBy(xpath="//*[@id=\"newpassword\"]")
	WebElement newPassword;
	
	@FindBy(xpath="//*[@id=\"register-form\"]/div[5]/input")
	WebElement resetPassword;

	

	public WebElement setEmail() {
		return email;
	}

	public WebElement setAnswer() {
		return answer;
	}

	public WebElement setNewPassword() {
		return newPassword;
	}

	public WebElement setResetPassword() {
		return resetPassword;
	}
	
	
	

}
