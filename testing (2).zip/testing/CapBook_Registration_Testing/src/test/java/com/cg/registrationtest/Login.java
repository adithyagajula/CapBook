package com.cg.registrationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	
	WebDriver driver;

	public Login(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"inputEmail\"]")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"inputPassword\"]")
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"Login\"]/button[1]")
	WebElement login;
	
	 @FindBy(xpath="//*[@id=\"Login\"]/button[2]")
	 WebElement register;
	 
	 @FindBy(xpath="//*[@id=\"Login\"]/div[3]/a[1]")
	 WebElement forgetPassword;
	
	 @FindBy(xpath="//*[@id=\"Login\"]/div[3]/a[2]")
	 WebElement changePassword;


	public WebElement getEmail() {
		return email;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getLogin() {
		return login;
	}

	public WebElement getRegister() {
		return register;
	}

	public WebElement getForgetPassword() {
		return forgetPassword;
	}

	public WebElement getChangePassword() {
		return changePassword;
	}
	
	 

	

}
