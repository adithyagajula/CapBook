package com.cg.registrationtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver driver;

	public HomePage(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
/*	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[1]/button")
	WebElement changePicture;*/
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[1]/button")
	WebElement changePicture;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[1]/input[1]")
	WebElement textStatus;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[1]/button[1]")
    WebElement postTextStatus;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[1]/input[2]")
	WebElement pictureStatus;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[1]/button[2]")
	WebElement postPictureStatus;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[4]/input")
	WebElement search;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[4]/button")
	WebElement searchButton;

	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[2]/button")
	WebElement deletePost;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[2]/div[1]/div[1]/input")
	WebElement textComment;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[2]/div[1]/div[1]/button")
	WebElement postComment;
	
	@FindBy(xpath="/html/body/app-root/app-userprofile/div[2]/div/div[2]/div[3]/div[2]/div/button/a")
	WebElement deletePicturePost;
	
	public WebElement setChangePicture() {
		return changePicture;
	}

	public WebElement setTextStatus() {
		return textStatus;
	}
	
	public WebElement setDeleteText() {
		return deletePost;
	}

	public WebElement setPostTextStatus() {
		return postTextStatus;
	}

	public WebElement setPictureStatus() {
		return pictureStatus;
	}

	public WebElement setPostPictureStatus() {
		return postPictureStatus;
	}

	public WebElement setSearch() {
		return search;
	}

	public WebElement setSearchButton() {
		return searchButton;
	}
	
	public WebElement setTextComment() {
		return textComment;
	}
	
	public WebElement setPostComment() {
		return postComment;
	}
	
	public WebElement setDeletePicturePost() {
		return deletePicturePost;
	}
	
	
}
